﻿# ninjalib is a data science library
# 
# import ninjalib
# cluster = ninjalib.ninjalib(data).cluster()
# combo = ninjalib.ninjalib(data).combo()
# flatten = ninjalib.ninjalib(data,nth=0).flatten()
# mean = ninjalib.ninjalib(data).mean()
#
# NOTES:
# cluster: list expected
# combo: list expected
# flatten: list or tuple expected; flatten nth times
# mean = list or tuple expected