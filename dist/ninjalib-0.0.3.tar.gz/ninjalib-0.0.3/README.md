﻿# ninjalib is a data science library
# 
# import ninjalib
# new_data = ninjalib.ninjalib(data).flatten_list()
# new_data = ninjalib.ninjalib(data).flatten_tuple()
# new_data = ninjalib.ninjalib(focal_length,x,y,z).project()
# new_data = ninjalib.ninjalib(data,axis,angle).rotate_camera()
# new_data = ninjalib.ninjalib(data).varint()
# 
# Notes:
# project and rotate camera are for 3D rendering on a 2D plane
# varint is for Minecraft Java
# rotate_camera accepts data as a 2D list of x,y,z coordinates, axis as a string (x,y,or,z) and an angle (90 degrees for right angle)
