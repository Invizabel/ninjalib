﻿# lotl is a data science library
#
# import lotl
# new_data = lotl(data).flatten_list()
# new_data = lotl(data).flatten_tupe()
# new_data = lotl(data).mean()