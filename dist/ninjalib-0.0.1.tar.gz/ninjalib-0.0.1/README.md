﻿# ninjalib is a data science library
#
# import ninjalib
# new_data = ninjalib(data).flatten_list()
# new_data = ninjalib(data).flatten_tuple()
# new_data = ninjalib(data).mean()
# new_data = ninjalib(data).varint()