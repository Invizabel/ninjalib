﻿# ninjalib is a data science library
# 
# import ninjalib
# center = ninjalib.ninjalib(data).center()
# flatten = ninjalib.ninjalib(data,nth=0).flatten()
# mean = ninjalib.ninjalib(data).mean()
# 
# NOTES:
# center expects a 2D list/tuple of 2D OR 3D vertices. It will also accept a 1D list/tuple of floats and/or ints.
# flatten: list or tuple expected; flatten nth times
# mean = list or tuple expected
