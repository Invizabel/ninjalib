﻿# ninjalib is a data science library
# 
# import ninjalib
# combo = ninjalib.ninjalib(data).combo()
# cluster = ninjalib.ninjalib(data).diff()
# flatten = ninjalib.ninjalib(data,nth=0).flatten()
# mean = ninjalib.ninjalib(data).mean()
#
# NOTES:
# combo: list expected
# diff: list expected
# flatten: list or tuple expected; flatten nth times
# mean = list or tuple expected